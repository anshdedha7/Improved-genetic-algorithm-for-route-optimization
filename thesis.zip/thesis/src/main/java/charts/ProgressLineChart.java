package charts;

import javafx.application.Platform;
import javafx.scene.chart.LineChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import models.Objectives;

public class ProgressLineChart {
	final NumberAxis xAxis = new NumberAxis();
	final NumberAxis yAxis = new NumberAxis();
	final LineChart<Number, Number> lineChart = new LineChart<Number, Number>(xAxis, yAxis);
	private XYChart.Series<Number, Number> series = new XYChart.Series<Number, Number>();

	public ProgressLineChart() {
		series.setName(Objectives.getPrimaryObjName());
		yAxis.setForceZeroInRange(false);
		run();
	}

	public void addSeries(int gen, int value) {
		series.getData().add(new XYChart.Data<Number, Number>(gen, value));
		lineChart.getData().clear();
		lineChart.getData().add(series);
	}

	public void clearData() {
		Platform.runLater(() -> {
			series.getData().clear();
		});
	}

	public LineChart<Number, Number> getLineChart() {
		return lineChart;
	}

	private void run() {
		Platform.runLater(() -> {
			createLineChart(xAxis);
		});
	}

	private void createLineChart(NumberAxis xAxis) {
		xAxis.setLabel("generations");
		lineChart.setAnimated(false);
	}
}
