package controllers;

import java.awt.Color;
import java.text.DecimalFormat;
import java.util.List;
import java.util.Random;

import com.esri.arcgisruntime.concurrent.ListenableFuture;
import com.esri.arcgisruntime.geometry.Point;
import com.esri.arcgisruntime.geometry.PointCollection;
import com.esri.arcgisruntime.geometry.Polyline;
import com.esri.arcgisruntime.geometry.SpatialReferences;
import com.esri.arcgisruntime.mapping.view.Graphic;
import com.esri.arcgisruntime.mapping.view.GraphicsOverlay;
import com.esri.arcgisruntime.mapping.view.IdentifyGraphicsOverlayResult;
import com.esri.arcgisruntime.mapping.view.LayerSceneProperties.SurfacePlacement;
import com.esri.arcgisruntime.mapping.view.SceneView;
import com.esri.arcgisruntime.symbology.SimpleLineSymbol;
import com.esri.arcgisruntime.symbology.SimpleLineSymbol.Style;
import com.esri.arcgisruntime.symbology.SimpleMarkerSymbol;
import com.esri.arcgisruntime.symbology.TextSymbol;
import com.esri.arcgisruntime.util.ListenableList;

import charts.ProgressLineChart;
import javafx.application.Platform;
import javafx.geometry.Point2D;
import javafx.scene.control.TableView;
import models.Objectives;
import models.Progress;

public class Visualizer {
	private static GraphicsOverlay graphicsOverlay;
	private static TableView<Progress> tableView;
	private static ProgressLineChart lineChart;
	private static int numberOfPathsDrawn = 0;
	private static ListenableFuture<IdentifyGraphicsOverlayResult> identifyGraphics;
	private static DecimalFormat df = new DecimalFormat("#.##");
	private static boolean isCostVisible = false;
	private static final int transparent = 0x22FF0000;
	private static final int white = 0xFFFF0000;
	private static final float blockSize = 12.0f;

	public static void graphicClicked(Point2D mapViewPoint, SceneView sceneView) {
		identifyGraphics = sceneView.identifyGraphicsOverlayAsync(graphicsOverlay, mapViewPoint, 0.1, false);
		identifyGraphics.addDoneListener(() -> Platform.runLater(createGraphicDialog(sceneView, mapViewPoint)));
	}

	private static Runnable createGraphicDialog(SceneView sceneView, Point2D mapViewPoint) {
		try {
			// get the list of graphics returned by identify
			IdentifyGraphicsOverlayResult result = identifyGraphics.get();
			List<Graphic> graphics = result.getGraphics();

			if (!graphics.isEmpty()) {
				// show a alert dialog box if a graphic was returned
				Graphic polyline = graphics.get(0);
				int i = (int) polyline.getAttributes().get("i");
				int j = (int) polyline.getAttributes().get("j");
				System.out.println(i + ", " + j);
				if (polyline.isSelected()) {
					polyline.setSelected(false);
					SimpleMarkerSymbol pointSymbol = new SimpleMarkerSymbol(SimpleMarkerSymbol.Style.SQUARE,
							transparent, blockSize);
					polyline.setSymbol(pointSymbol);
					Grid.blocked[i][j] = false;
				} else {
					polyline.setSelected(true);
					SimpleMarkerSymbol pointSymbol = new SimpleMarkerSymbol(SimpleMarkerSymbol.Style.SQUARE,
							transparent, blockSize);
					pointSymbol.setOutline(new SimpleLineSymbol(Style.SOLID, white, 1.0f));
					polyline.setSymbol(pointSymbol);
					Grid.blocked[i][j] = true;
				}
			}
		} catch (Exception e) {
			// on any error, display the stack trace
			e.printStackTrace();
		}
		return null;
	}

	public static void initializeOverlays(SceneView sceneView) {
		graphicsOverlay = new GraphicsOverlay();
		graphicsOverlay.getSceneProperties().setSurfacePlacement(SurfacePlacement.DRAPED);
		sceneView.getGraphicsOverlays().add(graphicsOverlay);
	}

	public static void initializeTableView(TableView<Progress> tableView) {
		Visualizer.tableView = tableView;
	}

	public static void drawPoint(Point point, int i, int j) {
		if (graphicsOverlay != null) {
			SimpleMarkerSymbol pointSymbol = new SimpleMarkerSymbol(SimpleMarkerSymbol.Style.SQUARE, transparent,
					blockSize);
			if (Grid.blocked[i][j]) {
				pointSymbol.setOutline(new SimpleLineSymbol(Style.SOLID, white, 1.0f));
			}

			Graphic pointGraphic = new Graphic(point, pointSymbol);
			pointGraphic.getAttributes().put("i", i);
			pointGraphic.getAttributes().put("j", j);
			if (Grid.blocked[i][j]) {
				pointGraphic.setSelected(true);
			}
			graphicsOverlay.getGraphics().add(pointGraphic);
		}
	}

	public static void drawPoint(Point point) {
		if (graphicsOverlay != null) {
			SimpleMarkerSymbol pointSymbol = new SimpleMarkerSymbol();
			pointSymbol = new SimpleMarkerSymbol(SimpleMarkerSymbol.Style.CROSS, 0xFFFFFF00, 30.0f);
			Graphic pointGraphic = new Graphic(point, pointSymbol);
			graphicsOverlay.getGraphics().add(pointGraphic);
		}
	}

	public static void drawPath(Individual individual) {
		PointCollection polylinePoints = new PointCollection(SpatialReferences.getWgs84());
		for (int i = 0; i < Grid.height; i++) {
			Point temp_point = Grid.getMapPoint(i, individual.getGene(i));
			polylinePoints.add(temp_point);
		}
		if (graphicsOverlay != null) {
			Polyline polyline = new Polyline(polylinePoints);
			Graphic polylineGraphic = new Graphic(polyline,
					new SimpleLineSymbol(SimpleLineSymbol.Style.SOLID, getRandomColor(), 2));
			graphicsOverlay.getGraphics().add(polylineGraphic);
			numberOfPathsDrawn++;
		}
	}

	public static void drawResultPath(Individual individual) {
		PointCollection polylinePoints = new PointCollection(SpatialReferences.getWgs84());
		for (int i = 0; i < Grid.height; i++) {
			Point temp_point = Grid.getMapPoint(i, individual.getGene(i));
			polylinePoints.add(temp_point);
		}
		if (graphicsOverlay != null) {
			Polyline polyline = new Polyline(polylinePoints);
//			Map<String,Object> attributes = new HashMap<String, Object>();
//			attributes.put("Cost", individual.getFitness(Objectives.getObjectiveOne()));
			Graphic polylineGraphic = new Graphic(polyline,
					new SimpleLineSymbol(SimpleLineSymbol.Style.SOLID, getRandomColor(), 2));
			polylineGraphic.getAttributes().put("Cost", individual.getFitness(Objectives.getPrimaryObjective()));

			graphicsOverlay.getGraphics().add(polylineGraphic);
			numberOfPathsDrawn++;
		}
	}

	public static void erasePaths() {
		ListenableList<Graphic> list = graphicsOverlay.getGraphics();
		int last = list.size();
		for (int i = 0; i < numberOfPathsDrawn; i++) {
			list.remove(last - i - 1);
		}
		numberOfPathsDrawn = 0;
	}

	public static void removeSelection() {
		ListenableList<Graphic> list = graphicsOverlay.getGraphics();
		if (isCostVisible) {
			list.remove(list.size() - 1);
			isCostVisible = false;
		}

		int last = list.size();
		for (int i = 0; i < numberOfPathsDrawn; i++) {
			list.get(last - i - 1).setSelected(false);
		}
	}

	private static int getRandomColor() {
		Random rand = new Random();
		float r = rand.nextFloat();
		float g = rand.nextFloat();
		float b = rand.nextFloat();
		Color randomColor = new Color(r, g, b);
		int color = randomColor.brighter().getRGB();
		return color;
	}

	public static Progress updateTable(int i, double fitness, double sd) {
		Platform.runLater(() -> {
			tableView.scrollTo(tableView.getItems().size() - 2);
		});
		Progress progress = new Progress();
		progress.setGen(i);
		progress.setDelta(fitness);
		progress.setDist(fitness);
		progress.setStandardDeviation(Math.round(sd * 100.0) / 100.0);
		tableView.getItems().add(progress);
		return progress;
	}

	public static void clearTable() {
		tableView.getItems().clear();
	}

	public static void initializeProgressLineChart(ProgressLineChart lineChart) {
		Visualizer.lineChart = lineChart;
	}

	public static void updateProgressLineChart(int gen, double fitness) {
		Platform.runLater(() -> {
			lineChart.addSeries(gen, (int) fitness);
		});
	}

	public static void showText(String string, Point2D mapViewPoint, SceneView sceneView) {
		TextSymbol txtSymbol = new TextSymbol(30, string, Color.YELLOW.getRGB(), TextSymbol.HorizontalAlignment.RIGHT,
				TextSymbol.VerticalAlignment.TOP);
		Point pt = sceneView.screenToBaseSurface(mapViewPoint);

		Graphic gr = new Graphic(pt, txtSymbol);
		graphicsOverlay.getGraphics().add(gr);
	}
}
