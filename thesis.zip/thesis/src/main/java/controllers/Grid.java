package controllers;

import com.esri.arcgisruntime.geometry.Point;
import com.esri.arcgisruntime.mapping.view.SceneView;

import models.DataPoint;
import models.MetaData;

public class Grid {
	public static Point startPoint;
	public static Point endPoint;
	public static int height = MetaData.getInstance().height;
	public static int width = MetaData.getInstance().width;
	private static DataPoint[][] data = new DataPoint[height][width];
	public static boolean[][] blocked = new boolean[height][width];
	private static int quadrant = -1;

	public static DataPoint[][] getData() {
		return data;
	}

	public static void initializePoints(SceneView sceneView) {
		Point startPoint = Grid.startPoint;
		Point endPoint = Grid.endPoint;
		double yDiff = endPoint.getY() - startPoint.getY();
		double xDiff = endPoint.getX() - startPoint.getX();
		boolean isYDiffGreater = Math.abs(yDiff) > Math.abs(xDiff);
		double axisDist;
		if (isYDiffGreater) {
			axisDist = Math.abs(yDiff);
		} else {
			axisDist = Math.abs(xDiff);
		}
		double verticalStepSize = axisDist / (double) (height - 1);
		double horizontalStepSize = axisDist / (double) (width);
		double vertical_m = (endPoint.getY() - startPoint.getY()) / (endPoint.getX() - startPoint.getX());
		double horizontal_m = -1 / vertical_m;
		quadrant = getQuadrant(yDiff, xDiff);
		double vertical_c = startPoint.getY() - (vertical_m * startPoint.getX());

		Point midPoint = new Point(startPoint.getX(), startPoint.getY());
		int widthCenter = width / 2;
		for (int row = 0; row < height; row++) {
			double horizontal_c = midPoint.getY() - (horizontal_m * midPoint.getX());
			Point rowPoint = new Point(midPoint.getX(), midPoint.getY());
			for (int col = widthCenter - 1; col >= 0; col--) {
				data[row][col] = new DataPoint(rowPoint);
				rowPoint = getLeftPoint(quadrant, horizontalStepSize, horizontal_m, horizontal_c, rowPoint.getY(),
						rowPoint.getX(), isYDiffGreater);
			}

			rowPoint = new Point(midPoint.getX(), midPoint.getY());
			for (int col = widthCenter; col < width; col++) {
				rowPoint = getRightPoint(quadrant, horizontalStepSize, horizontal_m, horizontal_c, rowPoint.getY(),
						rowPoint.getX(), isYDiffGreater);
				data[row][col] = new DataPoint(rowPoint);
			}
			midPoint = getNextMidPoint(quadrant, verticalStepSize, vertical_m, vertical_c, midPoint.getY(),
					midPoint.getX(), isYDiffGreater);
		}
	}

	private static Point getRightPoint(int quadrant, double horizontalStepSize, double horizontal_m,
			double horizontal_c, double yNew, double xNew, boolean isYDiffGreater) {
		isYDiffGreater = !isYDiffGreater;
		switch (quadrant) {
		case 1:
			if (isYDiffGreater) {
				yNew -= horizontalStepSize;
			} else {
				xNew += horizontalStepSize;
			}
			break;

		case 2:
			if (isYDiffGreater) {
				yNew += horizontalStepSize;
			} else {
				xNew += horizontalStepSize;
			}
			break;

		case 3:
			if (isYDiffGreater) {
				yNew += horizontalStepSize;
			} else {
				xNew -= horizontalStepSize;
			}
			break;

		case 4:
			if (isYDiffGreater) {
				yNew -= horizontalStepSize;
			} else {
				xNew -= horizontalStepSize;
			}
			break;

		default:
			break;
		}

		if (isYDiffGreater) {
			xNew = (yNew - horizontal_c) / horizontal_m;
		} else {
			yNew = horizontal_m * xNew + horizontal_c;
		}

		return new Point(xNew, yNew);
	}

	private static Point getLeftPoint(int quadrant, double horizontalStepSize, double horizontal_m, double horizontal_c,
			double yNew, double xNew, boolean isYDiffGreater) {
		isYDiffGreater = !isYDiffGreater;
		switch (quadrant) {
		case 1:
			if (isYDiffGreater) {
				yNew += horizontalStepSize;
			} else {
				xNew -= horizontalStepSize;
			}
			break;

		case 2:
			if (isYDiffGreater) {
				yNew -= horizontalStepSize;
			} else {
				xNew -= horizontalStepSize;
			}
			break;

		case 3:
			if (isYDiffGreater) {
				yNew -= horizontalStepSize;
			} else {
				xNew += horizontalStepSize;
			}
			break;

		case 4:
			if (isYDiffGreater) {
				yNew += horizontalStepSize;
			} else {
				xNew += horizontalStepSize;
			}
			break;

		default:
			break;
		}

		if (isYDiffGreater) {
			xNew = (yNew - horizontal_c) / horizontal_m;
		} else {
			yNew = horizontal_m * xNew + horizontal_c;
		}

		return new Point(xNew, yNew);
	}

	private static Point getNextMidPoint(int quadrant, double stepSize, double m, double c, double yNew, double xNew,
			boolean isYDiffGreater) {
		switch (quadrant) {
		case 1:
			if (isYDiffGreater) {
				yNew += stepSize;
			} else {
				xNew += stepSize;
			}
			break;

		case 2:
			if (isYDiffGreater) {
				yNew += stepSize;
			} else {
				xNew -= stepSize;
			}
			break;

		case 3:
			if (isYDiffGreater) {
				yNew -= stepSize;
			} else {
				xNew -= stepSize;
			}
			break;

		case 4:
			if (isYDiffGreater) {
				yNew -= stepSize;
			} else {
				xNew += stepSize;
			}
			break;

		default:
			break;
		}

		if (isYDiffGreater) {
			xNew = (yNew - c) / m;
		} else {
			yNew = m * xNew + c;
		}

		return new Point(xNew, yNew);
	}

	private static int getQuadrant(double yDiff, double xDiff) {
		if (xDiff > 0) {
			if (yDiff > 0)
				return 1;
			else
				return 4;
		} else {
			if (yDiff > 0)
				return 2;
			else
				return 3;
		}
	}

	public static double slope(double z1, double z2) {
		return (Math.abs(z1 - z2) * 3.28084);
	}

	public static DataPoint getDataPoint(int i, int j) {
		return data[i][j];
	}

	public static Point getMapPoint(int i, int j) {
		return data[i][j].getPoint();
	}

	public static int getQuadrant() {
		return quadrant;
	}

	public static void setQuadrant(int quadrant) {
		Grid.quadrant = quadrant;
	}

	public static void visualize() {
		for (int i = 0; i < data.length; i++) {
			for (int j = 0; j < data[0].length; j++) {
				Visualizer.drawPoint(data[i][j].getPoint(), i, j);
			}
		}
	}
}
