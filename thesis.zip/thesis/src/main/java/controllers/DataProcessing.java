package controllers;

import java.math.BigDecimal;
import java.math.RoundingMode;

import models.MetaData;
import models.Segment;

public class DataProcessing {

	public static double calculateDeltaFitness(Individual individual) {
		double totalDelta = 0;

		for (int i = 1; i < Grid.height; i++) {
			int col1 = individual.getGene(i - 1);
			int col2 = individual.getGene(i);
			int delta = col2 - col1;
			if (delta <= 1) {
				totalDelta += Math.abs(delta);
			} else {
				int direction = delta / Math.abs(delta);
				totalDelta += Math.abs(delta);
				for (int j = 1; j < Math.abs(delta); j++) {
					int newCo1 = (col1 + direction * j);
					if (newCo1 >= 0 && newCo1 < Grid.width && Grid.blocked[i - 1][newCo1]) {
						totalDelta += MetaData.getPenalty();
					}
				}
			}
			if (Grid.blocked[i - 1][col1]) {
				totalDelta += MetaData.getPenalty();
			}
			if (Grid.blocked[i][col2]) {
				totalDelta += MetaData.getPenalty();
			}
		}
		return totalDelta;
	}

	public static double calculateDistFitness(Individual individual) {
		double totalDist = 0;
		for (int i = 0; i < Grid.height - 1; i++) {
			int[] startCoordinates = new int[] { i, individual.getGene(i) };
			int[] endCoordinates = new int[] { i + 1, individual.getGene(i + 1) };

			totalDist += segmentDist(startCoordinates, endCoordinates);

		}
		return totalDist;
	}

	private static double segmentDist(int[] startCoordinates, int[] endCoordinates) {
		Segment segment = new Segment(startCoordinates, endCoordinates);
		return segment.getDist();
	}

	public static double round(double value, int places) {
		if (places < 0)
			throw new IllegalArgumentException();

		BigDecimal bd = BigDecimal.valueOf(value);
		bd = bd.setScale(places, RoundingMode.HALF_UP);
		return bd.doubleValue();
	}

}

//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
