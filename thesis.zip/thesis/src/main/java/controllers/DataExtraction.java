package controllers;

import com.esri.arcgisruntime.geometry.Envelope;
import com.esri.arcgisruntime.geometry.Point;
import com.esri.arcgisruntime.geometry.SpatialReferences;
import com.esri.arcgisruntime.mapping.view.LocationToScreenResult;
import com.esri.arcgisruntime.mapping.view.SceneView;

import javafx.geometry.Point2D;
import models.DataPoint;
import models.Segment;

public class DataExtraction {

	public static void loadData(SceneView sceneView) {
//		DataPoint[][] data = Grid.getData();
//		Viewpoint vp = new Viewpoint(getEnvelop(data));
//		sceneView.setViewpoint(vp);
//
//		data = loadElevationData(sceneView, data);

		Segment.setData(Grid.getData());
		sceneView.requestFocus();
	}

	private static DataPoint[][] loadElevationData(SceneView sceneView, DataPoint[][] data) {
		for (int i = 0; i < data.length; i++) {
			for (int j = 0; j < data[0].length; j++) {
				LocationToScreenResult locationToScreenResult = sceneView.locationToScreen(
						new Point(data[i][j].getX(), data[i][j].getY(), SpatialReferences.getWgs84()));
				Point2D point2d = locationToScreenResult.getScreenPoint();
				Point point = sceneView.screenToBaseSurface(point2d);
				data[i][j] = new DataPoint(point);
			}
		}
		return data;
	}

	private static Envelope getEnvelop(DataPoint[][] data) {
		double x1 = 0, x2 = 0, y1 = 0, y2 = 0;
		int h = Grid.height, w = Grid.width;
		switch (Grid.getQuadrant()) {
		case 1:
		case 3:
			x1 = data[h - 1][0].getX();
			y1 = data[h - 1][0].getY();
			x2 = data[0][w - 1].getX();
			y2 = data[0][w - 1].getY();
			break;
		case 2:
		case 4:
			x1 = data[0][0].getX();
			y1 = data[0][0].getY();
			x2 = data[h - 1][w - 1].getX();
			y2 = data[h - 1][w - 1].getY();
			break;
		}
		return new Envelope(x1, y1, x2, y2, SpatialReferences.getWgs84());
	}
}
