package controllers;

import java.io.Serializable;
import java.util.Comparator;
import java.util.concurrent.ThreadLocalRandom;

import models.Fitness;
import models.Objectives;

public class Individual implements Comparable<Individual>, Comparator<Individual>, Serializable {
	private int[] genes;
	private Fitness fitness;
	private int islandSelectionCount = 0;

	public Individual(boolean initialize) {
		genes = new int[Grid.height];
		if (initialize) {
			int prev = (Grid.width - 1) / 2;
			int momentum = ThreadLocalRandom.current().nextInt(0, (int) (Grid.width / 10));
			int direction = 1;
			if (Math.random() <= 0.5) {
				direction = -1;
			}

			momentum = direction * momentum;
			genes[0] = prev;

			for (int i = 1; i < (Grid.height - 1); i++) {
				if (i > Grid.height - 7) {
					momentum = ((prev - ((Grid.width - 1) / 2)) / ((Grid.height - 1 - i) * 5)) * -1;
					prev += momentum;
				} else {
					if ((prev + momentum) >= 0 && (prev + momentum) < Grid.width && momentum != 0) {
						prev += momentum;
						if (momentum > 3) {
							momentum = (int) Math.round(momentum * 0.75);
						} else if (momentum < -3) {
							momentum = (int) Math.round(momentum * 0.75);
						} else {
							if (momentum < 0 && Math.random() < 0.5) {
								momentum += 1;
							} else if (momentum == -1 && Math.random() < 0.3) {
								momentum = -2;
							}
							if (momentum > 0 && Math.random() < 0.5) {
								momentum -= 1;
							} else if (momentum == 1 && Math.random() < 0.3) {
								momentum = 2;
							}
						}
					} else {
						if (momentum == 0) {
							if (Math.random() < 0.5) {
								direction = direction * -1;
								momentum = direction;
							}
						} else {
							direction = direction * -1;
							momentum = direction;
						}
					}
				}
				genes[i] = prev;
			}

			genes[Grid.height - 1] = (Grid.width - 1) / 2;
		}
	}

	@Override
	public int compare(Individual o1, Individual o2) {
		return o1.compareTo(o2);
	}

	public int compareTo(Individual path) {

		double compareQuantity = path.getFitness(Objectives.getPrimaryObjective());
		if (this.getFitness(Objectives.getPrimaryObjective()) > compareQuantity)
			return 1;
		else if (compareQuantity > this.getFitness(Objectives.getPrimaryObjective()))
			return -1;

		return 0;
	}

	public void incrementIslandSelectionCount() {
		setIslandSelectionCount(getIslandSelectionCount() + 1);
	}

	public Fitness getFitness() {
		if (fitness == null) {
			calculateFitness();
		}
		return fitness;
	}

	public void setFitness(Fitness fitness) {
		this.fitness = fitness;
	}

	public double getFitness(int objectiveType) {
		switch (objectiveType) {
		case Objectives.DELTA:
			return DataProcessing.calculateDeltaFitness(this);
		case Objectives.DIST:
			return DataProcessing.calculateDistFitness(this);
		default:
			break;
		}
		return -1;
	}

	public int getGene(int i) {
		return this.genes[i];
	}

	public void setGene(int index, int point) {
		genes[index] = point;
		this.fitness = null;
	}

	public void visualize(boolean eraseExistingPaths) {
		if (eraseExistingPaths)
			Visualizer.erasePaths();
		Visualizer.drawPath(this);
	}

	private void calculateFitness() {
		fitness = new Fitness();
		switch (Objectives.getPrimaryObjective()) {
		case Objectives.DELTA:
			fitness.setDelta(DataProcessing.calculateDeltaFitness(this));
			break;
		case Objectives.DIST:
			fitness.setDist(DataProcessing.calculateDistFitness(this));
			break;
		default:
			break;
		}

	}

	public int getIslandSelectionCount() {
		return islandSelectionCount;
	}

	public void setIslandSelectionCount(int islandSelectionCount) {
		this.islandSelectionCount = islandSelectionCount;
	}

	public void visualizeResult(boolean eraseExistingPaths) {
		if (eraseExistingPaths)
			Visualizer.erasePaths();
		Visualizer.drawResultPath(this);
	}

	public String getNumberOfErrors() {
		int error = 0;
		for (int i = 0; i < genes.length; i++) {
			if (Grid.blocked[i][genes[i]]) {
				error++;
			}
		}
		return "" + error;
	}
}
