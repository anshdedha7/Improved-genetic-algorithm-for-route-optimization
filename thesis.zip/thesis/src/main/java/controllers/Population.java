package controllers;

import java.io.Serializable;
import java.util.Arrays;
import java.util.HashMap;

import models.Objectives;

public class Population implements Serializable {
	private Individual[] individuals;
	private HashMap<Integer, Individual> fittestIndividuals = new HashMap<>();

	public Population(int populationSize, boolean initialise) {
		individuals = new Individual[populationSize];

		if (initialise) {
			for (int i = 0; i < populationSize; i++) {
				Individual newIndiv = new Individual(true);
				saveIndividual(i, newIndiv);
			}
		}
	}

	public void saveIndividual(int i, Individual indiv) {
		this.individuals[i] = indiv;
	}

	public Individual getIndividual(int id) {
		return this.individuals[id];
	}

	public int size() {
		return individuals.length;
	}

	public void sortIndividuals() {
		Arrays.sort(individuals);
	}

	public Individual getFittest(int objective) {
		Individual fittest = this.fittestIndividuals.get(objective);
		if (fittest == null) {
			individuals[0].getFitness(objective);
			fittest = individuals[0];
			for (int i = 1; i < individuals.length; i++) {
				if (fittest.getFitness(objective) >= individuals[i].getFitness(objective)) {
					fittest = individuals[i];
				}
			}
			this.fittestIndividuals.put(objective, fittest);
		}
		return fittest;
	}

	public void visualize() {
		Visualizer.erasePaths();
		for (int i = 0; i < individuals.length; i++) {
			individuals[i].visualize(false);
		}
	}

	public void updateLineChart(int gen) {
		Visualizer.updateProgressLineChart(gen,
				this.getFittest(Objectives.getPrimaryObjective()).getFitness(Objectives.getPrimaryObjective()));
	}

	public double[] getMeanDensity() {
		double[] mean = new double[Grid.height];
		for (int i = 0; i < size(); i++) {
			Individual individual = getIndividual(i);
			for (int j = 0; j < Grid.height; j++) {
				mean[j] += individual.getGene(j);
			}
		}

		double size = (double) size();
		for (int i = 0; i < Grid.height; i++) {
			mean[i] = mean[i] / size;
		}

		return mean;
	}

	public double getStandardDeviation(double[] meanDensity) {
		double[] sd = new double[Grid.height];
		for (int i = 0; i < size(); i++) {
			Individual individual = getIndividual(i);
			for (int j = 0; j < Grid.height; j++) {
				sd[j] += Math.pow((individual.getGene(j) - meanDensity[j]), 2);
			}
		}

		double size = (double) size();
		for (int i = 0; i < Grid.height; i++) {
			sd[i] = Math.sqrt(sd[i] / size);
		}

		double sum = 0;

		for (double x : sd)
			sum += x;

		double standardDeviation = sum / sd.length;
		System.out.println(standardDeviation);
		return standardDeviation;
	}

	public double getStandardDeviation() {
		double[] meanDensity = getMeanDensity();
		double[] sd = new double[Grid.height];
		for (int i = 0; i < size(); i++) {
			Individual individual = getIndividual(i);
			for (int j = 0; j < Grid.height; j++) {
				sd[j] += Math.pow((individual.getGene(j) - meanDensity[j]), 2);
			}
		}

		double size = (double) size();
		for (int i = 0; i < Grid.height; i++) {
			sd[i] = Math.sqrt(sd[i] / size);
		}

		double sum = 0;

		for (double x : sd)
			sum += x;

		double standardDeviation = sum / sd.length;
//		System.out.println(standardDeviation);
		return standardDeviation;
	}

	public double getCoefficiantOfVariance() {
		double[] md = getMeanDensity();
		double[] sd = new double[Grid.height];
		for (int i = 0; i < size(); i++) {
			Individual individual = getIndividual(i);
			for (int j = 0; j < Grid.height; j++) {
				sd[j] += Math.pow((individual.getGene(j) - md[j]), 2);
			}
		}

		double size = (double) size();
		for (int i = 0; i < Grid.height; i++) {
			sd[i] = Math.sqrt(sd[i] / size);
		}

		double[] cv = new double[Grid.height];
		for (int i = 0; i < cv.length; i++) {
			cv[i] = (sd[i] * 100) / md[i];
		}

		double sum = 0;

		for (double x : cv)
			sum += x;

		double cov = sum / cv.length;
		System.out.println(cov);
		return cov;
	}
}
