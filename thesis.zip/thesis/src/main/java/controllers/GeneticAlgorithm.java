package controllers;

import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.concurrent.ThreadLocalRandom;

import models.MetaData;
import models.Objectives;
import models.Progress;
import models.Result;

public class GeneticAlgorithm {

	private int populationSize;
	private int islandThreshold;
	private int tournamentSize;

	public GeneticAlgorithm(int populationSize, int islandThreshold) {
		this.populationSize = populationSize;
		this.islandThreshold = islandThreshold;
		this.tournamentSize = (int) Math.ceil((double) populationSize / MetaData.getInstance().numOfTournamentGroups);
	}

	public Result optimizeForSingleObjective() {
		int gen = 1;
		ArrayList<Progress> progressList = new ArrayList<>();
		MetaData metaData = MetaData.getInstance();
		Population population = new Population(this.populationSize, true);

		population.updateLineChart(gen);
		Visualizer.clearTable();
		MetaData.resetPenalty();
		if (metaData.isEnableFullPopulationVisualization) {
			population.visualize();
		} else {
			population.getFittest(Objectives.getPrimaryObjective()).visualize(true);
		}
		long startTime = System.currentTimeMillis();
		while (gen < 500) {
			double sd = population.getStandardDeviation();
			saveGenToCSV(gen, sd);
			progressList.add(Visualizer.updateTable(gen, population.getFittest(Objectives.getPrimaryObjective())
					.getFitness(Objectives.getPrimaryObjective()), sd));
			if (gen % metaData.visualizationFrequency == 0) {
				if (metaData.isEnableFullPopulationVisualization) {
					population.visualize();
				} else {
					population.getFittest(Objectives.getPrimaryObjective()).visualize(true);
				}
				population.updateLineChart(gen);
//				if (sd <= metaData.standardDeviationForConvergence
//						&& MetaData.getPenalty() > (metaData.highestPenalty)) {
//					System.out.println(gen + ": Done.");
//					break;
//				}
			}
			population = evolveForSingleObjective(population);
			if (MetaData.getPenalty() < metaData.highestPenalty) {
				MetaData.setPenalty(MetaData.getPenalty() * metaData.rateOfChangeInPenalty);
			}
			gen++;
		}
		long stopTime = System.currentTimeMillis();
		long elapsedTime = stopTime - startTime;
		Result result = new Result(population, metaData, progressList, elapsedTime);
		return result;
	}

	private Population evolveForSingleObjective(Population pop) {
		Population newPopulation = new Population(pop.size(), false);

		// Elitism
		Individual fittest = pop.getFittest(Objectives.getPrimaryObjective());
		newPopulation.saveIndividual(0, islandSelection(fittest));

		// Island selection method
		for (int i = 1; i < pop.size(); i++) {
			Individual indiv = islandSelection(pop.getIndividual(i));
			if (indiv.getIslandSelectionCount() < islandThreshold) {
				newPopulation.saveIndividual(i, indiv);
			} else {
				newPopulation.saveIndividual(i, mutate(tournamentSelection(pop)));
			}
		}

////	 Crossover
//		for (int i = 1; i < pop.size(); i++) {
//			if (Math.random() <= 0.8) {
//				Individual indiv1 = tournamentSelection(pop);
//				Individual indiv2 = tournamentSelection(pop);
//				Individual newIndiv = crossover(indiv1, indiv2);
//				newPopulation.saveIndividual(i, newIndiv);
//			} else {
//				newPopulation.saveIndividual(i, tournamentSelection(pop));
//			}
//		}
//
////	// Mutate population
//		for (int i = 1; i < newPopulation.size(); i++) {
//			if (Math.random() <= 0.2) {
//				newPopulation.saveIndividual(i, mutate(newPopulation.getIndividual(i)));
//			}
//		}

		return newPopulation;
	}

	private Individual islandSelection(Individual individual) {
		Population tournament = new Population(tournamentSize, false);
		tournament.saveIndividual(0, individual);
		for (int i = 1; i < tournamentSize; i++) {
			tournament.saveIndividual(i, mutate(individual));
		}
		Individual fittest = tournament.getFittest(Objectives.getPrimaryObjective());
		fittest.incrementIslandSelectionCount();
		return fittest;
	}

	private Individual tournamentSelection(Population pop) {
		Population tournament = new Population(tournamentSize, false);

		for (int i = 0; i < tournamentSize; i++) {
			int randomId = ThreadLocalRandom.current().nextInt(0, pop.size());
			tournament.saveIndividual(i, pop.getIndividual(randomId));
		}
		return tournament.getFittest(Objectives.getPrimaryObjective());
	}

	private Individual crossover(Individual indiv1, Individual indiv2) {
		Individual newSol1 = new Individual(false);
		Individual newSol2 = new Individual(false);
		int breakPoint = -1;
		int boundary = (int) Math.ceil(Grid.height * 0.05);
		for (int i = boundary; i < Grid.height - boundary; i++) {
			if (indiv1.getGene(i) == indiv2.getGene(i)) {
				breakPoint = i;
			}
		}

		if (breakPoint != -1) {
			for (int i = 0; i < Grid.height; i++) {
				if (i <= breakPoint) {
					newSol1.setGene(i, indiv1.getGene(i));
					newSol2.setGene(i, indiv2.getGene(i));
				} else {
					newSol1.setGene(i, indiv2.getGene(i));
					newSol2.setGene(i, indiv1.getGene(i));
				}
			}
			Population compare = new Population(2, false);
			compare.saveIndividual(0, newSol1);
			compare.saveIndividual(1, newSol2);
			return compare.getFittest(Objectives.getPrimaryObjective());
		} else {
			if (Math.random() < 0.5) {
				return mutate(indiv1);
			} else {
				return mutate(indiv2);
			}

		}
	}

	private Individual mutate(Individual indiv) {

//		if (Math.random() <= 0.5) {
//			return blockMutate(indiv);
//		}

		Individual path = new Individual(false);

		double shift = 1;
		if (Math.random() <= 0.5) {
			shift = -1;
		}

		int highestRange = (int) (Grid.height * 0.5);
		int mutationRange = ThreadLocalRandom.current().nextInt(1, highestRange);
		if (mutationRange > 3) {
			shift = shift * ThreadLocalRandom.current().nextInt(1, mutationRange / 2);
		}
		int startMut = ThreadLocalRandom.current().nextInt(1, Grid.height - mutationRange - 1);
		int endMut = startMut + mutationRange;
		double midMut = (startMut + endMut) / 2;
		double midRange = mutationRange / 2;
		for (int i = 0; i < Grid.height; i++) {
			if (i > startMut && i < endMut) {
				double distSqr;
				if (i < midMut) {
					distSqr = Math.pow((i - startMut), 2);
				} else {
					distSqr = Math.pow(endMut - i, 2);
				}
				int nextShift = (int) (shift * (distSqr / (midRange * midRange)));
				if (indiv.getGene(i) + nextShift < Grid.width && indiv.getGene(i) + nextShift >= 0) {
					path.setGene(i, indiv.getGene(i) + nextShift);
				}
			} else {
				path.setGene(i, indiv.getGene(i));
			}
		}
		return path;
	}

	private Individual simpleMutate(Individual indiv) {
		Individual path = new Individual(false);
		int length = Grid.height;

		for (int i = 0; i < length; i++) {
			path.setGene(i, indiv.getGene(i));
		}

		int random = ThreadLocalRandom.current().nextInt(0, Grid.height);
		int gene = indiv.getGene(random);
		if (gene == 0) {
			path.setGene(random, 1);
		} else if (gene == Grid.height - 1) {
			path.setGene(random, Grid.height - 2);
		} else {
			if (Math.random() < 0.5) {
				path.setGene(random, gene - 1);
			} else {
				path.setGene(random, gene + 1);
			}
		}
		return path;
	}

	private static Individual blockMutate(Individual indiv) {
		Individual path = new Individual(false);

		int direction = 1;
		if (Math.random() <= 0.5) {
			direction = -1 * direction;
		}
		int shift = ThreadLocalRandom.current().nextInt(1, 4) * direction;

		double startMut;
		double endMut;
		int length = Grid.height;
		if (Math.random() <= 0.1) {
			if (Math.random() <= 0.5) {
				startMut = -1;
				endMut = ThreadLocalRandom.current().nextInt(0, (int) (length * 0.2));
			} else {
				startMut = ThreadLocalRandom.current().nextInt((int) (length * 0.8), length);
				endMut = length;
			}
		} else {
			startMut = ThreadLocalRandom.current().nextInt(0, length);
			if (startMut < length - 3 && Math.random() < 0.1) {
				endMut = startMut + 2;
			} else {
				endMut = ThreadLocalRandom.current().nextInt(0, length);
			}
		}
		if (endMut < startMut) {
			double temp = startMut;
			startMut = endMut;
			endMut = temp;
		}
		path.setGene(0, indiv.getGene(0));
		for (int i = 1; i < length - 1; i++) {
			if (i > startMut && i < endMut) {
				if (indiv.getGene(i) + shift < length && indiv.getGene(i) + shift >= 0) {
					path.setGene(i, indiv.getGene(i) + shift);
				} else {
					path.setGene(i, indiv.getGene(i));
				}
			} else {
				path.setGene(i, indiv.getGene(i));
			}
		}
		path.setGene(length - 1, indiv.getGene(length - 1));
		return path;
	}

	private static void saveGenToCSV(int gen, double sd) {
		String fileName = null;
		try {
			fileName = "sd.csv";
			FileWriter pw = new FileWriter(fileName, true);

			pw.append("" + gen);
			pw.append(',');

			pw.append("" + sd);
			pw.append("\n");

			pw.flush();
			pw.close();
		} catch (FileNotFoundException e) {
			System.out.println("File not found");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
