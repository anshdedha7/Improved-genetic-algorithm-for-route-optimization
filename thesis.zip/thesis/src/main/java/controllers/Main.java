package controllers;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import com.esri.arcgisruntime.geometry.Point;
import com.esri.arcgisruntime.geometry.SpatialReferences;
import com.esri.arcgisruntime.mapping.ArcGISScene;
import com.esri.arcgisruntime.mapping.ArcGISTiledElevationSource;
import com.esri.arcgisruntime.mapping.Basemap;
import com.esri.arcgisruntime.mapping.Surface;
import com.esri.arcgisruntime.mapping.view.Camera;
import com.esri.arcgisruntime.mapping.view.SceneView;

import charts.ProgressLineChart;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Point2D;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import models.MetaData;
import models.Objectives;
import models.Progress;
import models.Result;

public class Main extends Application {

	private static final String ELEVATION_IMAGE_SERVICE = "http://elevation3d.arcgis.com/arcgis/rest/services/WorldElevation3D/Terrain3D/ImageServer";
	private static final int BUTTON_HEIGHT = 30;
	private static final int BUTTON_WIDTH = 200;

	public static void main(String[] args) {
		Application.launch(args);
	}

	@Override
	public void start(Stage primaryStage) throws Exception {
		createUI(primaryStage);
	}

	private void createUI(Stage primaryStage) {
		primaryStage.setHeight(2000);
		primaryStage.setWidth(2000);
		HBox hBox1 = new HBox();
//		hBox1.getStylesheets().add("styles/application.css");
		createSidePanel(hBox1);
		SceneView sceneView = createMapScene(primaryStage, hBox1);
		Visualizer.initializeOverlays(sceneView);
		sceneView.setOnMouseClicked(event -> {
			if (event.isStillSincePress() && event.getButton() == MouseButton.PRIMARY) {
				mapClicked(sceneView, event);
			}
		});
	}

	private void mapClicked(SceneView sceneView, MouseEvent event) {
		Point2D mapViewPoint = new Point2D(event.getX(), event.getY());
		if (Grid.startPoint == null) {
			Grid.startPoint = new Point(-95.33544128497093, 29.717843264160813, SpatialReferences.getWgs84());
//			Grid.startPoint = sceneView.screenToBaseSurface(mapViewPoint);
			Visualizer.drawPoint(Grid.startPoint);
		} else if (Grid.endPoint == null) {
			Grid.endPoint = new Point(-95.35071832136586, 29.72356172115709, SpatialReferences.getWgs84());
//			Grid.endPoint = sceneView.screenToBaseSurface(mapViewPoint);
			Visualizer.drawPoint(Grid.endPoint);
			endPointSelected(sceneView);
		} else {
//			Visualizer.removeSelection();
			Visualizer.graphicClicked(mapViewPoint, sceneView);
		}
	}

	private void endPointSelected(SceneView sceneView) {
		loadBlockData();
		Grid.initializePoints(sceneView);
		DataExtraction.loadData(sceneView);
		Grid.visualize();
	}

	private SceneView createMapScene(Stage primaryStage, HBox hBox1) {
		StackPane stackPane = new StackPane();
		stackPane.scaleXProperty();
		hBox1.getChildren().add(stackPane);
		HBox.setHgrow(stackPane, Priority.ALWAYS);
		Scene fxScene = new Scene(hBox1);

		ArcGISScene scene = new ArcGISScene();
		scene.setBasemap(Basemap.createImagery());

		SceneView sceneView = new SceneView();
		sceneView.setArcGISScene(scene);
		stackPane.getChildren().add(sceneView);

		Camera camera = new Camera(29.7199, -95.3422, 1300, 0, 0.0, 0);
		sceneView.setViewpointCamera(camera);

		Surface surface = new Surface();
		surface.getElevationSources().add(new ArcGISTiledElevationSource(ELEVATION_IMAGE_SERVICE));
		scene.setBaseSurface(surface);

		primaryStage.setTitle("Algorithm Test");
		primaryStage.setScene(fxScene);
		primaryStage.show();
		return sceneView;
	}

	private void createSidePanel(HBox hBox) {
		VBox vBox1 = new VBox();
		vBox1.setPadding(new Insets(15, 15, 15, 15));
		vBox1.setSpacing(5);

		Button startBtn = new Button("Start");
		startBtn.setId("btn-dark-blue");
		startBtn.setMinSize(BUTTON_WIDTH, BUTTON_HEIGHT);
		startBtn.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				ProgressLineChart progressLineChart = new ProgressLineChart();
				Visualizer.initializeProgressLineChart(progressLineChart);
				progressLineChart.getLineChart().setMaxHeight(BUTTON_HEIGHT * 12);
				vBox1.getChildren().add(progressLineChart.getLineChart());
				vBox1.getChildren().add(creatTableView());
				startButtonClicked(startBtn, progressLineChart);
			}
		});

		Button resultsBtn = new Button("Save data");
		resultsBtn.setId("btn-dark-blue");
		resultsBtn.setMinSize(BUTTON_WIDTH, BUTTON_HEIGHT);
		resultsBtn.setOnAction(new EventHandler<ActionEvent>() {
			@Override
			public void handle(ActionEvent event) {
				resultsButtonClicked();
			}
		});

		HBox hb = new HBox();
		hb.setMinWidth(15);
		HBox vBox_buttons = new HBox(startBtn, hb, resultsBtn);
		vBox1.getChildren().add(vBox_buttons);
		hBox.getChildren().add(vBox1);
	}

	private TableView<Progress> creatTableView() {
		TableView<Progress> tableView = new TableView<Progress>();
		tableView.setPrefHeight(BUTTON_HEIGHT * 12);
		TableColumn<Progress, String> column1 = new TableColumn<Progress, String>("Gen");
		column1.setCellValueFactory(new PropertyValueFactory<>("gen"));
		tableView.getColumns().add(column1);
		TableColumn<Progress, String> column2 = new TableColumn<Progress, String>(Objectives.getPrimaryObjName());
		column2.setCellValueFactory(new PropertyValueFactory<>(Objectives.getPrimaryObjName()));
		tableView.getColumns().add(column2);
		TableColumn<Progress, String> column3 = new TableColumn<Progress, String>("SD");
		column3.setCellValueFactory(new PropertyValueFactory<>("standardDeviation"));
		tableView.getColumns().add(column3);
		Visualizer.initializeTableView(tableView);
		return tableView;
	}

	private void startButtonClicked(Button startBtn, ProgressLineChart progressLineChart) {
		try {
			new Thread(() -> {
				progressLineChart.clearData();
				Platform.runLater(() -> {
					startBtn.setText("...");
					startBtn.setDisable(true);
				});
				MetaData metaData = MetaData.getInstance();
				GeneticAlgorithm algorithm = new GeneticAlgorithm(metaData.populationSize, metaData.islandThreshold);
				Result result = algorithm.optimizeForSingleObjective();
				saveResultToCSV(result);
				if (metaData.isEnableFullPopulationVisualization) {
					result.getPopulation().visualize();
				} else {
					result.getPopulation().getFittest(Objectives.getPrimaryObjective()).visualize(true);
				}

				System.out.println("Complete");
				Platform.runLater(() -> {
					startBtn.setText("Restart");
					startBtn.setDisable(false);
					startBtn.setOnAction(new EventHandler<ActionEvent>() {
						@Override
						public void handle(ActionEvent event) {
							startButtonClicked(startBtn, progressLineChart);
						}
					});
				});
			}).start();
		} catch (Exception e) {
			System.out.println("ERROR");
		}
	}

	private void setParams(String param) {
		String[] parArray = param.split(",");
		MetaData metaData = MetaData.getInstance();
		String[] gridSize = parArray[0].split("x");
		metaData.height = Integer.parseInt(gridSize[0]);
		metaData.width = Integer.parseInt(gridSize[1]);
		metaData.populationSize = Integer.parseInt(parArray[1]);
		metaData.visualizationFrequency = Integer.parseInt(parArray[2]);
		metaData.islandThreshold = Integer.parseInt(parArray[3]);
		metaData.rateOfChangeInPenalty = Double.parseDouble(parArray[4]);
	}

	private void resultsButtonClicked() {

//		ArrayList<String> filenames = listFilesForFolder(new File(RESULTS_FILE_NAME));
//		MetaData meta = MetaData.getInstance();
//		for (String filename : filenames) {
//			if (!filename.contains("result")) {
//				continue;
//			}
//			Result result = readResultFromFile(RESULTS_FILE_NAME + filename);
//			if (result.getMetaData().height == meta.height && result.getMetaData().width == meta.width) {
//				Individual individual = result.getPopulation().getFittest(Objectives.getObjectiveOne());
//				individual.visualizeResult(false);
//			}
//		}

		String fileName = null;
		try {
			fileName = "blocked.txt";
			FileOutputStream f = new FileOutputStream(new File(fileName));
			ObjectOutputStream o = new ObjectOutputStream(f);

			// Write objects to file
			o.writeObject(Grid.blocked);

			o.close();
			f.close();

		} catch (FileNotFoundException e) {
			System.out.println("File not found");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private void loadBlockData() {
		boolean[][] res = null;
		try {
			FileInputStream fi = new FileInputStream(new File("blocked.txt"));
			ObjectInputStream oi = new ObjectInputStream(fi);

			// Read objects
			res = (boolean[][]) oi.readObject();
			oi.close();
			fi.close();
		} catch (FileNotFoundException e) {
			System.out.println("File not found");
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

		Grid.blocked = res;
	}

	private ArrayList<String> listFilesForFolder(final File folder) {
		ArrayList<String> fileList = new ArrayList<>();
		for (final File fileEntry : folder.listFiles()) {
			if (fileEntry.isDirectory()) {
				listFilesForFolder(fileEntry);
			} else {
				fileList.add(fileEntry.getName());
			}
		}
		return fileList;
	}

	private String saveResultToFile(Result result) {
		result.getMetaData().saveCoordinates();
		String fileName = null;
		try {
			String timeStamp = new SimpleDateFormat("MM-dd-HH-mm-ss").format(new Date());
			fileName = "results/result-" + timeStamp + ".txt";
			FileOutputStream f = new FileOutputStream(new File(fileName));
			ObjectOutputStream o = new ObjectOutputStream(f);

			// Write objects to file
			o.writeObject(result);

			o.close();
			f.close();

		} catch (FileNotFoundException e) {
			System.out.println("File not found");
		} catch (IOException e) {
			e.printStackTrace();
		}
		return fileName;
	}

	private Result readResultFromFile(String filename) {
		Result res = null;
		try {
			FileInputStream fi = new FileInputStream(new File(filename));
			ObjectInputStream oi = new ObjectInputStream(fi);

			// Read objects
			res = (Result) oi.readObject();
			oi.close();
			fi.close();
		} catch (FileNotFoundException e) {
			System.out.println("File not found");
		} catch (IOException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}
		return res;
	}

	private String saveResultToCSV(Result result) {
		result.getMetaData().saveCoordinates();
		String fileName = null;
		try {
			fileName = "result.csv";
			FileWriter pw = new FileWriter(fileName, true);

			String timeStamp = new SimpleDateFormat("MM-dd-HH-mm-ss").format(new Date());
			pw.append(timeStamp);
			pw.append(',');

			ArrayList<Progress> progressList = result.getProgressList();
			Progress latestProgress = progressList.get(progressList.size() - 1);
			int gen = latestProgress.getGen();

			pw.append("" + gen);
			pw.append(',');

			MetaData metaData = result.getMetaData();

			pw.append("" + metaData.populationSize);
			pw.append(',');

			pw.append("" + metaData.islandThreshold);
			pw.append(',');

			pw.append("" + metaData.startingPenalty);
			pw.append(',');

			pw.append("" + metaData.rateOfChangeInPenalty);
			pw.append(',');

			pw.append("" + metaData.highestPenalty);
			pw.append(',');

			pw.append("" + MetaData.getPenalty());
			pw.append(',');

			pw.append("" + Objectives.getPrimaryObjName());
			pw.append(',');

			Population population = result.getPopulation();

			pw.append("" + population.getFittest(0).getFitness(0));
			pw.append(',');

			pw.append("" + population.getFittest(1).getFitness(1));
			pw.append(',');

			pw.append("" + metaData.numOfTournamentGroups);
			pw.append(',');

			pw.append("" + latestProgress.getStandardDeviation());
			pw.append(',');

			pw.append("" + population.getFittest(Objectives.getPrimaryObjective()).getNumberOfErrors());
			pw.append(',');

			pw.append(result.getExecutionTime() + "");

			pw.append("\n");

			pw.flush();
			pw.close();
		} catch (FileNotFoundException e) {
			System.out.println("File not found");
		} catch (IOException e) {
			e.printStackTrace();
		}
		return fileName;
	}
}
