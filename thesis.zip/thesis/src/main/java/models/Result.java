package models;

import java.io.Serializable;
import java.util.ArrayList;

import controllers.Population;

public class Result implements Serializable {
	private Population population;
	private MetaData metaData;
	private ArrayList<Progress> progressList;
	private long executionTime;

	public Result(Population population, MetaData metaData, ArrayList<Progress> progressList, long time) {
		this.population = population;
		this.metaData = metaData;
		this.progressList = progressList;
		this.executionTime = time;
	}

	public Population getPopulation() {
		return population;
	}

	public void setPopulation(Population population) {
		this.population = population;
	}

	public MetaData getMetaData() {
		return metaData;
	}

	public void setMetaData(MetaData metaData) {
		this.metaData = metaData;
	}

	public ArrayList<Progress> getProgressList() {
		return progressList;
	}

	public void setProgressList(ArrayList<Progress> progressList) {
		this.progressList = progressList;
	}

	public long getExecutionTime() {
		return executionTime;
	}

	public void setExecutionTime(long executionTime) {
		this.executionTime = executionTime;
	}
}
