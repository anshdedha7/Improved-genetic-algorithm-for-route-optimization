package models;

import java.io.Serializable;

public class Fitness implements Serializable {
	private double delta;
	private double dist;

	public double getDelta() {
		return delta;
	}

	public void setDelta(double delta) {
		this.delta = delta;
	}

	public double getDist() {
		return dist;
	}

	public void setDist(double dist) {
		this.dist = dist;
	}

	public double getFitnessById(int objectiveNumber) {
		switch (objectiveNumber) {
		case Objectives.DELTA:
			return this.delta;
		case Objectives.DIST:
			return this.dist;

		default:
			break;
		}
		return -1;
	}
}
