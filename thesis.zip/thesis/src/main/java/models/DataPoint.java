package models;

import com.esri.arcgisruntime.geometry.Point;

public class DataPoint {
	private Point point;

	public DataPoint(Point point) {
		this.setPoint(point);
	}

	public Point getPoint() {
		return point;
	}

	public void setPoint(Point point) {
		this.point = point;
	}

	public double getZ() {
		return point.getZ();
	}

	public double getY() {
		return point.getY();
	}

	public double getX() {
		return point.getX();
	}
}
