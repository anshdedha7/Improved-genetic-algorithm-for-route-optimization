package models;

import java.io.Serializable;

import controllers.Grid;

class Coordinates implements Serializable {
	public double startX;
	public double startY;
	public double endX;
	public double endY;

	public Coordinates() {
		this.startX = Grid.startPoint.getX();
		this.startY = Grid.startPoint.getY();
		this.endX = Grid.endPoint.getX();
		this.endY = Grid.endPoint.getY();
	}
}

public class MetaData implements Serializable {
	private static MetaData instance = null;

	private static double PENALTY = -1;

	public Coordinates coordinates;
	public boolean isEnableFullPopulationVisualization = false;
	public int height = 100;
	public int width = 100;
	public int populationSize = 100;
	public int islandThreshold = 8;
	public double numOfTournamentGroups = 20.0;
	public int visualizationFrequency = 25;
	public double standardDeviationForConvergence = 5;
	public double rateOfChangeInPenalty = 1.05;
	public double startingPenalty = 0.7;
	public double highestPenalty = 7;

	private MetaData() {
	}

	public static MetaData getInstance() {
		if (instance == null) {
			instance = new MetaData();
		}
		return instance;
	}

	public void saveCoordinates() {
		this.coordinates = new Coordinates();
	}

	public void toggleFullPopulationVisualization() {
		if (isEnableFullPopulationVisualization) {
			isEnableFullPopulationVisualization = false;
		} else {
			isEnableFullPopulationVisualization = true;
		}
	}

	public static void resetPenalty() {
		PENALTY = getInstance().startingPenalty;
	}

	public static double getPenalty() {
		if (PENALTY == -1) {
			PENALTY = getInstance().startingPenalty;
		}
		return PENALTY;
	}

	public static void setPenalty(double p) {
		PENALTY = p;
	}
}
