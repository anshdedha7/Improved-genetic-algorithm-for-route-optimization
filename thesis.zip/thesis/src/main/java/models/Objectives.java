package models;

import java.io.Serializable;

public class Objectives implements Serializable {

	public final static int DELTA = 0;
	public final static int DIST = 1;

	public static int getPrimaryObjective() {
		return Objectives.DIST;
	}

	public static String getPrimaryObjName() {
		switch (getPrimaryObjective()) {
		case DELTA:
			return "Delta";
		case DIST:
			return "Dist";
		default:
			break;
		}
		return "";
	}
}
