package models;

import java.io.Serializable;

public class Progress implements Serializable {
	private int gen = 0;
	private double Delta = 0;
	private double Dist = 0;
	private double standardDeviation = 0;

	public Progress() {
	}

	public Progress(int gen, double delta, double dist, double standardDeviation) {
		this.setGen(gen);
		this.setDelta(delta);
		this.setDist(dist);
		this.setStandardDeviation(standardDeviation);
	}

	public int getGen() {
		return gen;
	}

	public void setGen(int gen) {
		this.gen = gen;
	}

	public double getDelta() {
		return Delta;
	}

	public void setDelta(double delta) {
		this.Delta = delta;
	}

	public double getDist() {
		return Dist;
	}

	public void setDist(double dist) {
		this.Dist = dist;
	}

	public double getStandardDeviation() {
		return standardDeviation;
	}

	public void setStandardDeviation(double standardDeviation) {
		this.standardDeviation = standardDeviation;
	}

}