package models;

import controllers.Grid;

public class PairOfPoints {
	private static DataPoint[][] data;
	private int[] startCoordinates;
	private int[] endCoordinates;
	private DataPoint startPoint;

	public DataPoint getStartPoint() {
		return startPoint;
	}

	private DataPoint endPoint;

	public DataPoint getEndPoint() {
		return endPoint;
	}

	private double slope = -1;
	private double sideSlope = -1;
	private double dist = -1;

	public PairOfPoints(int[] startCoordinates, int[] endCoordinates) {
		this.startCoordinates = startCoordinates;
		this.endCoordinates = endCoordinates;
		this.startPoint = data[startCoordinates[0]][startCoordinates[1]];
		this.endPoint = data[endCoordinates[0]][endCoordinates[1]];
	}

	public double getCost() {
		double thickness = 0.433821428571429;
		double tonsOfSteelPerFt = (1017.876019763098 - (Math.PI * Math.pow(18 - thickness, 2))) / 144.0 * 490 / 2000.0;
		double tonsOfSteel = tonsOfSteelPerFt * getDist();
		double costOfSteel = tonsOfSteel * 1400;
		double costOfCoating = 2.5 * getDist();
		double slopeDegree = getSlope();
		double slopeModifier;
		if (slopeDegree <= 10) {
			slopeModifier = 0;
		} else if (slopeDegree < 20) {
			slopeModifier = 0.1;
		} else if (slopeDegree < 30) {
			slopeModifier = 0.5;
		} else if (slopeDegree < 45) {
			slopeModifier = 1;
		} else {
			slopeModifier = 5;
		}
		double slopeCost = getDist() * slopeModifier * 500;

		double sideSlopeDegree = getSideSlope();
		double sideSlopeModifier;

		if (sideSlopeDegree <= 10) {
			sideSlopeModifier = 0;
		} else if (sideSlopeDegree < 20) {
			sideSlopeModifier = 0.1;
		} else if (sideSlopeDegree < 30) {
			sideSlopeModifier = 0.5;
		} else if (sideSlopeDegree < 45) {
			sideSlopeModifier = 1;
		} else {
			sideSlopeModifier = 5;
		}
		double sideSlopeCost = getDist() * sideSlopeModifier * 500;

		double landTypeModifier = 1;
		double landTypeCost = landTypeModifier * getDist() * 500;

		return costOfSteel + costOfCoating + slopeCost + sideSlopeCost + landTypeCost;
	}

	public double getSideSlope() {
		if (sideSlope != -1) {
			return sideSlope;
		}
		if (startCoordinates[0] == -1 || endCoordinates[0] == -1) {
			return 0;
		}
		if (startCoordinates[1] <= 0 || startCoordinates[1] >= Grid.height - 1) {
			return 50;
		}

		DataPoint sidePoint1;
		DataPoint sidePoint2;

		if (startCoordinates[0] == endCoordinates[0]) {
			if (startCoordinates[0] == 0) {
				sidePoint1 = data[1][startCoordinates[1]];
				sidePoint2 = data[0][startCoordinates[1]];
			} else if (startCoordinates[0] == Grid.height - 1) {
				sidePoint1 = data[Grid.height - 1][startCoordinates[1]];
				sidePoint2 = data[Grid.height - 2][startCoordinates[1]];
			} else {
				sidePoint1 = data[startCoordinates[0] + 1][startCoordinates[1]];
				sidePoint2 = data[startCoordinates[0] - 1][startCoordinates[1]];
			}
		} else {
			sidePoint1 = data[startCoordinates[0]][startCoordinates[1] + 1];
			sidePoint2 = data[startCoordinates[0]][startCoordinates[1] - 1];
		}
		sideSlope = Math.abs(sidePoint1.getZ() - sidePoint2.getZ()) * 3.28084; // feet
		sideSlope = feetToDegree(sideSlope);

		return sideSlope;
	}

	public double getSlope() {
		if (slope == -1) {
			slope = Math.abs(startPoint.getZ() - endPoint.getZ()) * 3.28084; // feet
			slope = feetToDegree(slope); // degree
		}
		return slope;
	}

	private double feetToDegree(double s) {
		return s * 100 / Math.pow((s * s) + (getDist() * getDist()), 0.5);
	}

	public double getDist() {
		if (dist == -1) {
			double earthRadius = 6371000; // meters
			double dLat = Math.toRadians(startPoint.getY() - endPoint.getY());
			double dLng = Math.toRadians(startPoint.getX() - endPoint.getX());
			double a = Math.sin(dLat / 2) * Math.sin(dLat / 2) + Math.cos(Math.toRadians(startPoint.getY()))
					* Math.cos(Math.toRadians(endPoint.getY())) * Math.sin(dLng / 2) * Math.sin(dLng / 2);
			double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
			float twoDimDist = (float) (earthRadius * c);
			dist = twoDimDist * 3.28084; // feet
			double temp = dist * MetaData.getPenalty();
			if (Grid.blocked[startCoordinates[0]][startCoordinates[1]]) {
				dist += temp;
			}
			if (Grid.blocked[endCoordinates[0]][endCoordinates[1]]) {
				dist += temp;
			}
		}
		return dist;
	}

	public static void setData(DataPoint[][] dataPoints) {
		PairOfPoints.data = dataPoints;
	}
}
