package models;

public class Segment {
	private static DataPoint[][] data;
	private int[] startCoordinates;
	private int[] endCoordinates;

	public Segment(int[] startCoordinates, int[] endCoordinates) {
		this.startCoordinates = startCoordinates;
		this.endCoordinates = endCoordinates;
	}

	public double getDist() {
		if (Math.abs(endCoordinates[1] - startCoordinates[1]) <= 1) {
			return pairOfPointsDist(startCoordinates, endCoordinates);
		}
		double dist = 0;
		int row = startCoordinates[0];
		if (startCoordinates[1] < endCoordinates[1]) {
			for (int col = startCoordinates[1]; col < endCoordinates[1] - 1; col++) {
				dist += pairOfPointsDist(new int[] { row, col }, new int[] { row, col + 1 });
			}
			dist += pairOfPointsDist(new int[] { row, endCoordinates[1] - 1 }, endCoordinates);
		} else {
			for (int col = startCoordinates[1]; col > endCoordinates[1] + 1; col--) {
				dist += pairOfPointsDist(new int[] { row, col }, new int[] { row, col - 1 });
			}
			dist += pairOfPointsDist(new int[] { row, endCoordinates[1] + 1 }, endCoordinates);
		}
		return dist;
	}

	private double pairOfPointsDist(int[] startPoint, int[] endPoint) {
		PairOfPoints pairOfPoints = new PairOfPoints(startPoint, endPoint);
		return pairOfPoints.getDist();
	}

	public static void setData(DataPoint[][] dataPoints) {
		PairOfPoints.setData(dataPoints);
		Segment.data = dataPoints;
	}
}
